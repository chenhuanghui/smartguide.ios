#import "BuyActivity.h"

@implementation BuyActivity

@end
