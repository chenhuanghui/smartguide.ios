#import "CheckInActivity.h"

@implementation CheckInActivity

@end
