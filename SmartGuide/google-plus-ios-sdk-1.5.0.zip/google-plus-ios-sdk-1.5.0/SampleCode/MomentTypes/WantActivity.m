#import "WantActivity.h"

@implementation WantActivity

@end
