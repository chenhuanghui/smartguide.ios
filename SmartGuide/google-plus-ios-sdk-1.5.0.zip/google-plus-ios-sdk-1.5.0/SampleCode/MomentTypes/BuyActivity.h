#import "Activity.h"

@interface BuyActivity : Activity

@end
