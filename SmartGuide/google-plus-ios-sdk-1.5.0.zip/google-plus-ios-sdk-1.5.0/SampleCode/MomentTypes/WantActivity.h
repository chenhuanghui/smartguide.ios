#import "Activity.h"

@interface WantActivity : Activity

@end
